import time
import json
import requests
import importlib.resources
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when


# -------------------------------------------------
# 1. EJECUTAR DDL DESDE EL WHEEL
# -------------------------------------------------
def run_ddl(spark):
    with importlib.resources.open_text(
        "tik_tok_pipeline", "DDL.txt"
    ) as f:
        ddl_script = f.read()

    for stmt in ddl_script.split(";"):
        if stmt.strip():
            spark.sql(stmt)

    print("DDL executed successfully from wheel.")


# -------------------------------------------------
# 2. LEER SECRETS
# -------------------------------------------------
def load_secrets(path="secrets.json"):
    with open(path, "r") as f:
        return json.load(f)


# -------------------------------------------------
# 3. AUTENTICACIÓN
# -------------------------------------------------
def authenticate(secrets):
    auth_url = "https://api.eazydi.com/easydiapp/api/auth/signin"

    credentials = {
        "username": secrets["eazydi"]["username"],
        "password": secrets["eazydi"]["password"]
    }

    response = requests.post(auth_url, json=credentials)
    response.raise_for_status()

    access_token = response.json().get("accessToken")
    token = f"Bearer {access_token}"

    print("Token obtained successfully.")
    return token


# -------------------------------------------------
# 4. CONSULTAR JOBS ARCHIVADOS
# -------------------------------------------------
def check_archived_jobs(token, secrets):
    url = "https://api.eazydi.com/easydiapp/api/monitor/archive"

    headers = {
        "Authorization": token,
        "X-EazydiTenant-Id": secrets["eazydi"]["tenant_id"],
        "Accept": "application/json"
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        print("Archived Jobs Listings retrieved.")
    else:
        raise RuntimeError(
            f"Archive error {response.status_code}: {response.text}"
        )


# -------------------------------------------------
# 5. REINICIAR BATCH
# -------------------------------------------------
def restart_batch(token, secrets):
    url = "https://api.eazydi.com/easydiapp/api/monitor/restart"

    headers = {
        "Authorization": token,
        "X-EazydiTenant-Id": secrets["eazydi"]["tenant_id"],
        "Content-Type": "application/json"
    }

    payload = {
        "batchid": secrets["eazydi"]["batch_id"]
    }

    response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 200:
        time.sleep(70)
        print("Job completed correctly.")
    else:
        raise RuntimeError(
            f"Restart error {response.status_code}: {response.text}"
        )


# -------------------------------------------------
# 6. TRANSFORMACIÓN SPARK
# -------------------------------------------------
def transform(spark):
    df_raw = spark.table("lnd_tiktok_raw")

    df_clean = (
        df_raw
        .withColumn("impressions", col("impressions").cast("int"))
        .withColumn("clicks", col("clicks").cast("int"))
        .withColumn("spend", col("spend").cast("float"))
        .withColumn("conversion", col("conversion").cast("int"))
        .withColumn("frequency", col("frequency").cast("float"))
        .withColumn("cash_spend", col("cash_spend").cast("float"))
        .withColumn("video_play_actions", col("video_play_actions").cast("int"))
        .withColumn("likes", col("likes").cast("int"))
        .withColumn("shares", col("shares").cast("int"))
        .withColumn("follows", col("follows").cast("int"))
        .withColumn("profile_visits", col("profile_visits").cast("int"))
        .withColumn(
            "ctr",
            when(
                col("impressions") != 0,
                col("clicks") / col("impressions")
            ).otherwise(None).cast("float")
        )
        .withColumn(
            "cpc",
            when(
                col("clicks") != 0,
                col("spend") / col("clicks")
            ).otherwise(None).cast("float")
        )
    )

    (
        df_clean
        .select(
            "ad_id", "adgroup_id", "campaign_id", "campaign_name",
            "impressions", "clicks", "spend", "ctr", "cpc",
            "conversion", "frequency", "cash_spend",
            "video_play_actions", "likes", "shares", "follows",
            "profile_visits", "country_code"
        )
        .write
        .mode("overwrite")
        .saveAsTable("fct_tiktok_ad_perf")
    )

    print("Transformation executed and data saved in fct_tiktok_ad_perf.")


# -------------------------------------------------
# 7. MAIN (ENTRY POINT DEL WHEEL)
# -------------------------------------------------
def main():
    spark = SparkSession.builder.getOrCreate()

    # 1. DDL
    run_ddl(spark)

    # 2. Secrets
    secrets = load_secrets()

    # 3. Auth
    token = authenticate(secrets)

    # 4. Check archived jobs
    check_archived_jobs(token, secrets)

    # 5. Restart batch
    restart_batch(token, secrets)

    # 6. Transform
    transform(spark)


# -------------------------------------------------
# ENTRY POINT PARA PYTHON WHEEL TASK
# -------------------------------------------------
if __name__ == "__main__":
    main()
